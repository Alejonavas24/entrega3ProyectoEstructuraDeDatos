package com.proyectoestructuradatos;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import Logica.HogaresLogica;

public class ObtenHogar extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_obten_hogar);
        String registro=getIntent().getStringExtra("retorno");
        TextView campoNombre =findViewById(R.id.VerNombre);
        TextView campoDireccion =findViewById(R.id.VerDireccion);
        TextView campoTelefono =findViewById(R.id.VerTelefono);
        if(registro!=null){

        String[] definitivo=registro.split(",");
        campoNombre.setText(definitivo[0]);
        campoDireccion.setText(definitivo[1]);
        campoTelefono.setText(definitivo[2]);
        }else{
            campoNombre.setText("No hay lugares disponibles :(");
            campoDireccion.setText("");
            campoTelefono.setText("");
        }
    }

    public void inicio(View view){
        Intent inicio=new Intent(this,MainActivity.class);
        startActivity(inicio);
    }
}
