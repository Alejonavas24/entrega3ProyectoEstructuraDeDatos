package com.proyectoestructuradatos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import Logica.LoginLogico;

public class Login extends AppCompatActivity {
    LoginLogico tablita =new LoginLogico();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }
    public void Ingresar(View view){
        EditText cuadrousuario=findViewById(R.id.CuadroUsuario);
        EditText cuandroclave=findViewById(R.id.CuadroContraseña);
        String Name= cuadrousuario.getText().toString();
        Object descripcion=cuandroclave.getText().toString();
        Object contraseña=tablita.Validar(Name);
        if(contraseña!=null) {
            String validar=contraseña.toString();
            String validar2=descripcion.toString();
            if (validar.compareTo(validar2) == 0) {
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
            } else   {
                cuadrousuario.setText("");
                cuandroclave.setText("");
                Toast.makeText(this,"Contraseña incorrecta",Toast.LENGTH_SHORT).show();
            }
            cuadrousuario.setText("");
            cuandroclave.setText("");
        }else if(contraseña==null){
            cuadrousuario.setText("");
            cuandroclave.setText("");
            Toast.makeText(this,"Usuario No Existe",Toast.LENGTH_SHORT).show();
        }
}

public void Registrar (View view){
    EditText cuadrousuario=findViewById(R.id.CuadroUsuario);
    EditText cuandroclave=findViewById(R.id.CuadroContraseña);
    String Name= cuadrousuario.getText().toString();
    Object descripcion=cuandroclave.getText();
    String vacio="";
    Object repetido=tablita.Validar(Name);
    if(repetido==null){
        tablita.CrearUsuario(Name, descripcion);
        cuadrousuario.setText("");
        cuandroclave.setText("");
        Toast.makeText(this,"Usuario Creado Exitosamente",Toast.LENGTH_SHORT).show();
    }else{
        Toast.makeText(this,"El ususario Ya existe",Toast.LENGTH_SHORT).show();
        cuadrousuario.setText("no");
        cuandroclave.setText("");
    }


}
}