package com.proyectoestructuradatos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import Logica.TurnosLogica;

public class Turnos extends AppCompatActivity {
    TurnosLogica fila=new TurnosLogica();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_turnos);
    }
    public void registrar (View view){
        EditText cuadronombre=findViewById(R.id.IngresoNombreTurno);
        EditText cuadrotelefono=findViewById(R.id.IngresoTelefonoTurno);
        EditText Cuadroemail=findViewById(R.id.IngresoEmailTurno);
        String nombre=cuadronombre.getText().toString();
        String telefono=cuadrotelefono.getText().toString();
        String email=Cuadroemail.getText().toString();
        String last=nombre+","+telefono+","+email;
        fila.agendarturno(nombre);
        Log.d("registro",last);
        Toast.makeText(this, "Turno agendado exitosamente", Toast.LENGTH_SHORT).show();
            Intent inicio=new Intent(this,MainActivity.class);
            startActivity(inicio);
        }
    }
