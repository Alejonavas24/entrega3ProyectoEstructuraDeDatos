package com.proyectoestructuradatos;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.Serializable;

import EstructurasDeDatos.Stack;
import Logica.HogaresLogica;

public class RegistroHogares extends AppCompatActivity implements Serializable {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_hogares);
    }
    public void Enviar(View view){
        EditText infocuadro=findViewById(R.id.IngresoNombre);
        EditText infodireccion=findViewById(R.id.IngresoDireccion);
        EditText infotelefono=findViewById(R.id.IngresoTelefono);
        String Nombre=infocuadro.getText().toString();
        String Direccion=infodireccion.getText().toString();
        String Telefono=infotelefono.getText().toString();
        String infocompleta=Nombre+" ,"+ Direccion +" ,"+Telefono;
        Toast.makeText(this,Nombre+" Gracias Por La Postulacion",Toast.LENGTH_LONG).show();

        Intent intent= new Intent(this,Hogares.class);
        intent.putExtra("info",infocompleta);
        startActivity(intent);
    }
}