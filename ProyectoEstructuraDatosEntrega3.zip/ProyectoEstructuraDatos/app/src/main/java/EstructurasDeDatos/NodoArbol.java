package EstructurasDeDatos;

public class NodoArbol {
    Object valor;
    NodoArbol HijoIzquieerrda;
    NodoArbol HijoDerecha;
    String Llave;
    public NodoArbol(String Key,Object contenido){
        this.Llave=Key;
        this.valor=contenido;
        this.HijoDerecha=null;
        this.HijoIzquieerrda=null;
    }
    public Object ObtenerValor(){

        return valor;
    }
}
