package Logica;
import EstructurasDeDatos.HashTable;

public class LoginLogico {
    HashTable ususarios = new HashTable();
    private String NombreUsuario;
    Object Value;
    public LoginLogico() {
        ususarios.add("alejonavas24",24092002);
    }
    public void CrearUsuario (String nombre, Object clave){
        NombreUsuario=nombre;
        Value=clave;
        if(ususarios.obtener(nombre)==null){
            ususarios.add(NombreUsuario,clave);
        }

    }

    public Object Validar(String usuario){
        Object Contraseña= ususarios.obtener(usuario);
        if(Contraseña!=null){
            return Contraseña;
        }else{
            return null;
        }

    }

}

