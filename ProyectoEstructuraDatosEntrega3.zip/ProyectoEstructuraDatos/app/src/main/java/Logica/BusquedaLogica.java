package Logica;
import java.util.Locale;
import java.util.Scanner;
import EstructurasDeDatos.Arbol;

public class BusquedaLogica {
        Arbol ola2=new Arbol();

        Arbol mascotas =new Arbol();
        String datos;
        String nombre;

        public BusquedaLogica() {
            datos=null;
            mascotas.Insertar("toby","chihuahua");
            mascotas.Insertar("tbone","golden retriver");
            mascotas.Insertar("rex","pastor aleman");

        }
        public void PublicarMascotas(String NombreInseertado, String DatosExtra){
            nombre=NombreInseertado.toLowerCase();
            datos=DatosExtra;
            mascotas.Insertar(nombre,datos);


        }
        public String BuscarMascota(String NombreInsertado){
            String estresado=NombreInsertado.toLowerCase();
           String resultado = mascotas.BuscarNodo(estresado);
           return resultado;



        }
}
