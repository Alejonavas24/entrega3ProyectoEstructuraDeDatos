package Logica;
import android.content.Intent;
import android.util.Log;

import EstructurasDeDatos.Cola;
import java.util.Scanner;

public class TurnosLogica {
    Cola orden =new Cola();
    String datos;

    public TurnosLogica(){
        datos=null;
    }

    public void agendarturno(String data){

        datos=data;
        orden.enqueue(datos);
        int x = orden.tamaño();
        if (x==0){
                Log.d("inf","Eres el siguiente");
        }else{
            Log.d("info","Tu numero de fila es : "+x);
        }
    }
    public int Verificarturno(){
        System.out.println("Ingresa tu nombre");
        Scanner fx = new Scanner(System.in);
        datos=fx.nextLine();
        int X =orden.Encontrarindex(datos);
        return X;
    }

    public Object TurnoSiguiente(){
        return orden.dequeue();
    }
}
